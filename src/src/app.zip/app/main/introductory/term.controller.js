(function () {
  //'use strict';

  angular
    .module('app.term')
    .controller('TermController', TermController);

  /** @ngInject */
  function TermController($rootScope, $location, $http, $state, api, $scope) 
  {
    debugger
    //var vm = this;
    console.log('Term Called');

  }
});
