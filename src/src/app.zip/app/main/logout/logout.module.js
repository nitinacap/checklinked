(function ()
{
    'use strict';

    angular
        .module('app.logout', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider)
    {
        $stateProvider.state('app.logout', {
            url    : '/logout'
        });
    }
})();