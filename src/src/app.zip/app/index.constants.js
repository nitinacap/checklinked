(function ()
{
    'use strict';

    angular
        .module('checklinked');
})();
